define([
  './addPanel',
  './arrayJoin',
  './dashUpload',
  './kibanaPanel',
  './kibanaSimplePanel',
  './ngBlur',
  './ngModelOnBlur',
  './tip',
  './confirmClick',
  './esVersion',
  './configModal',
  './resizable'
], function () {});
