define([
  './alertSrv',
  './dashboard',
  './fields',
  './filterSrv',
  './kbnIndex',
  './querySrv',
  './timer',
  './panelMove',
  './esVersion',
  './json2csv'
],
function () {});